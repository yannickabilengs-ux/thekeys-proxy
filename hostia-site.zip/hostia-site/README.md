# Hostia — Site vitrine consulting IA

## Structure

```
hostia-site/
├── index.html              ← le site vitrine (page principale)
├── tools/                  ← les 5 démos IA, débrandées (agence fictive "Atrium Immo")
│   ├── Hostia_Demo_Email.html
│   ├── Hostia_Demo_Documents.html
│   ├── Hostia_Demo_PV_AG.html
│   ├── Hostia_Demo_Rappel_Paiement.html
│   └── Hostia_Demo_Triage_Email.html
└── backend/                 ← proxy Node/Express (à pousser dans son propre repo GitHub)
    ├── server.js
    └── package.json
```

## Déploiement — backend (proxy IA)

1. Crée un nouveau repo GitHub, ex : `hostia-demos-proxy`
2. Pousse le contenu du dossier `backend/` dedans
3. Sur Render.com → New Web Service → connecte ce repo
   - Build command : `npm install`
   - Start command : `npm start`
   - Variable d'environnement : `ANTHROPIC_API_KEY` = ta clé API
4. Une fois déployé, note l'URL Render (ex : `https://hostia-demos-proxy.onrender.com`)

⚠️ Si l'URL Render que tu obtiens est différente de `hostia-demos-proxy.onrender.com`, il faut remplacer cette valeur dans les 5 fichiers du dossier `tools/` (chercher `hostia-demos-proxy.onrender.com` et remplacer par ta vraie URL).

## Déploiement — site vitrine

1. Crée un second repo GitHub, ex : `hostia-site` (ou mets `index.html` + `tools/` dans le même repo que le backend, à la racine du service statique — au choix)
2. Déploie en statique : Render (Static Site), Netlify, ou GitHub Pages fonctionnent tous très bien puisqu'il n'y a aucun appel serveur sur ces pages-là (seul le proxy a besoin d'un vrai serveur)

## À personnaliser avant envoi à un prospect

- [ ] Email de contact dans `index.html` (actuellement `contact@hostia-ia.be`, placeholder)
- [ ] Vérifier l'URL du proxy dans les 5 fichiers `tools/Hostia_Demo_*.html`
- [ ] Une fois que tu as un vrai nom de domaine, mettre à jour les liens

## Notes sur le rebranding

- Les 5 outils reprennent exactement la logique et les prompts validés avec The Keys Group, mais avec une agence fictive ("Atrium Immo") à la place — aucune donnée réelle de The Keys Group n'est exposée.
- Palette accent : brass/laiton (`#B8862E`) au lieu du bleu utilisé pour The Keys, typographie Fraunces + Inter (au lieu de Playfair + DM Sans) — pour éviter toute ressemblance visuelle.
